# AHW AI — MASTER FULL & FINAL BUILD

This package is the consolidated AHW AI master build created from the requirements accumulated in this conversation.

## What is real in this build
- Runnable Node.js server with persistent local database (`data/ahw-db.json`)
- Owner authentication and session handling
- Owner-only endpoints for sensitive controls
- Command routing and approval workflow
- Granular permissions with expiry/limits fields and revoke
- Accounting ledger, product records and dashboard calculations
- Backup creation
- Security events and emergency lockdown flag
- Owner Model Capture Studio using the browser camera/microphone
- Server-side encrypted Owner Clone Vault using AES-256-GCM
- Uploaded reference media can be imported into the encrypted vault
- Vault preview/revoke workflow
- Functional mobile-first PWA frontend
- Functional 3D-style meeting-room workspace
- Integrations authorization registry
- Marketplace seller onboarding record
- Device registration/testing registry
- Media/software/website job queue records
- Docker deployment

## Your supplied media
The two photos and one video supplied in the current conversation are stored under `private_owner_seed/`. They are NOT served as public web assets. The Owner must log in and explicitly choose `Import Current Reference Media` to encrypt them into `data/owner-vault/`.

For a public deployment, remove `private_owner_seed/` from the deployed image after the first authorized import, or better, import locally before publishing. The application never exposes that folder through the web server.

## External services
Shopify, Amazon, YouTube, TikTok, Meta, payment gateways, AI providers, telecom/call providers and cloud storage require the Owner's real OAuth/API authorization. This build creates the authorization record and integration boundary; it does not fabricate a successful connection or embed credentials.

## Run locally
1. Copy `.env.example` to `.env` and set a strong `OWNER_PASSWORD` and `AHW_VAULT_KEY`.
2. `node server/server.mjs`
3. Open `http://localhost:8080`.
4. Log in as the configured Owner.
5. In Owner Capture Studio, import the supplied reference media into the encrypted vault.

No npm packages are required.

## Docker
`docker compose up --build`

## Important production note
This is a real runnable master application, not a static HTML mockup. It is not a substitute for production cloud infrastructure, independent security audit, legally required compliance, or third-party OAuth/API permissions. Those are deployment/provider boundaries and are intentionally not faked.
