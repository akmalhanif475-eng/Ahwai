import {spawn} from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
const port=process.env.SMOKE_PORT||8098;
const env={...process.env,PORT:String(port),OWNER_EMAIL:'owner@test.local',OWNER_PASSWORD:'Test-Owner-2026!',AHW_VAULT_KEY:'test-vault-key-2026',NODE_ENV:'test'};
const data=path.resolve('data'); if(fs.existsSync(data))fs.rmSync(data,{recursive:true,force:true});
const child=spawn(process.execPath,['server/server.mjs'],{env,stdio:['ignore','pipe','pipe']});
let token='';
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function req(url,opt={}){const r=await fetch(`http://127.0.0.1:${port}${url}`,{...opt,headers:{...(opt.headers||{}),...(token?{authorization:`Bearer ${token}`}:{})}});let j={};const t=await r.text();try{j=JSON.parse(t)}catch{j={text:t}};if(!r.ok)throw new Error(`${url} -> ${r.status} ${t}`);return j}
try{
  await sleep(400);
  const h=await req('/api/health'); if(!h.ok)throw Error('health failed');
  const root=await fetch(`http://127.0.0.1:${port}/`); if(!root.ok)throw Error('root failed');
  const login=await req('/api/auth/login',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({email:env.OWNER_EMAIL,password:env.OWNER_PASSWORD})}); token=login.token;
  await req('/api/me'); await req('/api/dashboard'); await req('/api/departments');
  await req('/api/command',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({text:'create perfume marketing campaign'})});
  const product=await req('/api/products',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({name:'AHW Test Perfume',sku:'TEST-001',price:100,cost:40,stock:10})}); if(!product.id)throw Error('product failed');
  await req('/api/ledger',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({type:'income',amount:100,category:'test',note:'smoke'})});
  const job=await req('/api/jobs',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({type:'software_build',input:{requirements:'smoke test'}})}); if(job.status!=='queued')throw Error('job failed');
  await req('/api/devices',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({label:'Test Android',platform:'Android'})});
  const approval=await req('/api/approvals',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({action:'test_sensitive_action',payload:{ok:true}})}); await req(`/api/approvals/${approval.id}/approve`,{method:'POST'});
  await req('/api/permissions',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({subject:'test-role',actions:['view'],limits:{}})});
  await req('/api/integrations/connect',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({provider:'Test Provider',scopes:['read']})});
  await req('/api/security/events',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({type:'smoke_test',severity:'low',details:'OK'})});
  await req('/api/backups/create',{method:'POST'});
  console.log('SMOKE_TEST_OK');
} catch(e){console.error('SMOKE_TEST_FAILED',e);process.exitCode=1}
finally{child.kill('SIGTERM');}
