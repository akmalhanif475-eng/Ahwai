# AHW AI Master 2026 — Full-Stack Deployment

This build is a real Node.js full-stack application: the same server serves the frontend and the `/api/*` backend. It is **not** a static Netlify-only site.

## Free testing (recommended)
Render currently offers free Node.js Web Services for testing. Use the included `render.yaml` or create a Web Service with:
- Build: `npm install`
- Start: `npm start`
- Health check: `/api/health`
- Plan: Free

Set these environment variables in the host dashboard:
- `OWNER_EMAIL`
- `OWNER_PASSWORD`
- `AHW_VAULT_KEY`

The free tier has an ephemeral filesystem. This build therefore treats the JSON database, encrypted vault files, and local backups as **test storage only** on a free instance. Data can be lost after restart/redeploy/spin-down. Move the database and storage to persistent services before production.

## Local test
```bash
npm install
cp .env.example .env
# edit the three owner/security values
npm start
```
Open the URL shown by the server. The backend health endpoint is `/api/health`.

## Smoke test
```bash
npm run test:smoke
```

## Important security rule
The private owner seed media is intentionally **not included** in this deployable package. Upload owner media through the encrypted Owner Vault after deployment. Never publish private owner seed media on a static hosting site.

## Netlify
Do not use Netlify Static Site/Drop for this full-stack build. Netlify can serve the frontend, but it will not run this Node process or provide the local persistent filesystem that this version uses. Use a Node Web Service host for the full application.
